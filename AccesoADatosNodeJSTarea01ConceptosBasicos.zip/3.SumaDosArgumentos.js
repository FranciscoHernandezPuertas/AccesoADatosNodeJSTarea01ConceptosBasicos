function sumaDosArgumentos(a, b) {
    console.log(a + b);
}

// Ejemplo de uso
sumaDosArgumentos(3, 5); // Imprime 8