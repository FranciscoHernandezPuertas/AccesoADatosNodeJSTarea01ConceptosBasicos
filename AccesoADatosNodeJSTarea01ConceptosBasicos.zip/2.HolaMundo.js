function holaMundo(){
    console.log("¡Hola Mundo!");
}

holaMundo(); // Imprime ¡Hola Mundo!